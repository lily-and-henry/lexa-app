// ToS Guard - Popup Script

const screens = {
  idle: document.getElementById('screen-idle'),
  loading: document.getElementById('screen-loading'),
  results: document.getElementById('screen-results'),
  settings: document.getElementById('screen-settings'),
};

function showScreen(name) {
  Object.values(screens).forEach(s => s.classList.remove('active'));
  screens[name].classList.add('active');
}

// --- Settings ---
document.getElementById('settings-toggle').addEventListener('click', () => {
  showScreen('settings');
});

document.getElementById('back-btn').addEventListener('click', () => showScreen('idle'));

// --- Manual scan ---
document.getElementById('manual-scan-btn').addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
    if (!tab) return;
    chrome.tabs.sendMessage(tab.id, { type: 'GET_TOS_TEXT' }, (resp) => {
      if (chrome.runtime.lastError || !resp) {
        // Try injecting content script first
        chrome.scripting.executeScript(
          { target: { tabId: tab.id }, files: ['src/content.js'] },
          () => {
            setTimeout(() => {
              chrome.tabs.sendMessage(tab.id, { type: 'GET_TOS_TEXT' }, (r) => {
                if (r?.text) runScan(r.text, r.title, r.url);
              });
            }, 300);
          }
        );
        return;
      }
      if (resp.text) runScan(resp.text, resp.title, resp.url);
    });
  });
});

document.getElementById('done-btn').addEventListener('click', () => {
  showScreen('idle');
  checkCurrentPage();
});

document.getElementById('rescan-btn').addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
    if (!tab) return;
    chrome.tabs.sendMessage(tab.id, { type: 'GET_TOS_TEXT' }, (resp) => {
      if (resp?.text) runScan(resp.text, resp.title, resp.url);
    });
  });
});

// --- Core scan flow ---
async function runScan(text, title, url) {
  showScreen('loading');
  animateLoadingSteps();

  chrome.runtime.sendMessage({ type: 'RUN_ANALYSIS', text }, (response) => {
    if (chrome.runtime.lastError) {
      showError('Extension error: ' + chrome.runtime.lastError.message);
      return;
    }
    if (!response) {
      showError('No response from background worker.');
      return;
    }
    if (!response.success) {
      showError(response.error || 'Analysis failed. Check your API key in Settings.');
      return;
    }
    renderResults(response.result, title, url);
  });
}

const LOADING_STEPS = [
  'Reading document…',
  'Extracting clauses…',
  'Comparing with known-good ToS…',
  'Identifying red flags…',
  'Writing plain-English summary…'
];
let loadingInterval;
function animateLoadingSteps() {
  clearInterval(loadingInterval);
  let i = 0;
  const el = document.getElementById('loading-step');
  el.textContent = LOADING_STEPS[0];
  loadingInterval = setInterval(() => {
    i = (i + 1) % LOADING_STEPS.length;
    el.textContent = LOADING_STEPS[i];
  }, 1200);
}



function showError(msg) {
  clearInterval(loadingInterval);
  document.getElementById('results-content').innerHTML = `
    <div class="error-box">⚠️ ${escHtml(msg)}</div>
    <br/>
  `;
  showScreen('results');
}

// --- Render results ---
function renderResults(r, title, url) {
  clearInterval(loadingInterval);

  const riskClass = r.riskLevel || 'MEDIUM';
  const score = Math.min(100, Math.max(0, r.riskScore || 50));

  const flagCount = (r.redFlags || []).length;
  const topFlags = (r.redFlags || []).slice(0, 2);

  const dataColor = { Minimal: '#34d399', Standard: '#fbbf24', Extensive: '#f87171', Invasive: '#ff4444' };
  const rightsColor = { Strong: '#34d399', Moderate: '#fbbf24', Limited: '#f87171', 'Very Limited': '#ff4444' };

  // Full analysis content (hidden by default)
  const allFlagsHtml = flagCount > 0
    ? (r.redFlags || []).map(f => `
        <div class="flag-item">
          <span class="flag-icon">⚠️</span>
          <span>${escHtml(f)}</span>
        </div>`).join('')
    : `<div class="summary-item"><span class="summary-dot">●</span><span>No major red flags detected.</span></div>`;

  const summaryHtml = (r.summary || []).map(s => `
    <div class="summary-item">
      <span class="summary-dot">●</span>
      <span>${escHtml(s)}</span>
    </div>`).join('');

  document.getElementById('results-content').innerHTML = `
    <div style="margin-bottom:10px;">
      <div style="font-size:11px; color:#555; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
        ${escHtml(title || url || 'Terms of Service')}
      </div>
    </div>

    <!-- COMPACT: risk bar -->
    <div class="risk-bar-wrap">
      <div class="risk-header">
        <span class="risk-label">Risk Score</span>
        <span class="risk-badge ${riskClass}">${riskClass}</span>
      </div>
      <div class="risk-track">
        <div class="risk-fill ${riskClass}" id="risk-fill-el" style="width:0%"></div>
      </div>
      <div style="display:flex;justify-content:space-between;font-size:10px;color:#444;margin-top:3px;">
        <span>Safe</span><span>${score}/100</span><span>Danger</span>
      </div>
    </div>

    <!-- COMPACT: two pills -->
    <div class="meta-row">
      <div class="meta-pill">
        <div class="meta-pill-label">Data Collection</div>
        <div class="meta-pill-val" style="color:${dataColor[r.dataCollection] || '#bbb'}">${escHtml(r.dataCollection || '—')}</div>
      </div>
      <div class="meta-pill">
        <div class="meta-pill-label">Your Rights</div>
        <div class="meta-pill-val" style="color:${rightsColor[r.userRights] || '#bbb'}">${escHtml(r.userRights || '—')}</div>
      </div>
    </div>

    <!-- COMPACT: verdict -->
    <div class="verdict-box">
      <strong>Verdict</strong>
      ${escHtml(r.verdict || '')}
    </div>

    <!-- COMPACT: top 2 red flags only -->
    ${topFlags.length > 0 ? `
    <div class="section" style="margin-bottom:10px;">
      <div class="section-title">⚠️ Top Red Flags</div>
      ${topFlags.map(f => `
        <div class="flag-item">
          <span class="flag-icon">⚠️</span>
          <span>${escHtml(f)}</span>
        </div>`).join('')}
    </div>` : ''}

    <!-- EXPAND TOGGLE -->
    <button id="expand-btn" style="
      width:100%; background:transparent; border:1px solid #2a2a2e;
      border-radius:8px; color:#4f8ef7; font-size:12px; font-weight:600;
      padding:9px; cursor:pointer; margin-bottom:4px; transition:background 0.15s;
      display:flex; align-items:center; justify-content:center; gap:6px;
    ">
      <span id="expand-arrow">▸</span>
      <span id="expand-label">Full Analysis${flagCount > 2 ? ` · ${flagCount - 2} more flag${flagCount - 2 > 1 ? 's' : ''}` : ''}</span>
    </button>

    <!-- FULL ANALYSIS (collapsed) -->
    <div id="full-analysis" style="display:none; margin-top:4px;">
      <div class="section">
        <div class="section-title">⚠️ All Red Flags (${flagCount})</div>
        ${allFlagsHtml}
      </div>
      <div class="section">
        <div class="section-title">📋 What You're Agreeing To</div>
        ${summaryHtml}
      </div>
      <div class="section">
        <div class="section-title">📊 Compared to Standard ToS</div>
        <div class="benchmark-box">${escHtml(r.comparedToBenchmark || '')}</div>
      </div>
    </div>
  `;

  showScreen('results');

  // Animate risk bar
  setTimeout(() => {
    const fill = document.getElementById('risk-fill-el');
    if (fill) fill.style.width = score + '%';
  }, 80);

  // Toggle full analysis
  document.getElementById('expand-btn').addEventListener('click', () => {
    const panel = document.getElementById('full-analysis');
    const arrow = document.getElementById('expand-arrow');
    const label = document.getElementById('expand-label');
    const isOpen = panel.style.display !== 'none';
    panel.style.display = isOpen ? 'none' : 'block';
    arrow.textContent = isOpen ? '▸' : '▾';
    label.textContent = isOpen
      ? `Full Analysis${flagCount > 2 ? ` · ${flagCount - 2} more flag${flagCount - 2 > 1 ? 's' : ''}` : ''}`
      : 'Hide Full Analysis';
  });
}

// --- Check current page on popup open ---
function checkCurrentPage() {
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
    if (!tab) return;

    chrome.storage.local.get(['pendingScan', 'scanStatus'], (data) => {
      // Check if there's a pending scan from the content banner
      if (data.pendingScan && data.scanStatus === 'pending') {
        chrome.storage.local.set({ scanStatus: 'running' });
        runScan(data.pendingScan.text, data.pendingScan.title, data.pendingScan.url);
        chrome.storage.local.remove(['pendingScan']);
        return;
      }

      // Check if current page is a ToS
      chrome.tabs.sendMessage(tab.id, { type: 'CHECK_PAGE' }, (resp) => {
        if (chrome.runtime.lastError) return;
        if (resp?.isTos) {
          const idleContent = document.getElementById('idle-content');
          idleContent.innerHTML = `
            <div class="detected-banner">
              <div class="detected-dot"></div>
              <div class="detected-text">
                <div class="detected-title">Terms of Service Detected</div>
                ToS Guard found a legal agreement on this page.
              </div>
            </div>
            <div style="text-align:center; padding: 0 0 16px;">
              <button class="scan-manual-btn" id="detected-scan-btn">🔍 Scan for Red Flags</button>
            </div>
          `;
          document.getElementById('detected-scan-btn').addEventListener('click', () => {
            chrome.tabs.sendMessage(tab.id, { type: 'GET_TOS_TEXT' }, (r) => {
              if (r?.text) runScan(r.text, r.title, r.url);
            });
          });
        }
      });
    });
  });
}

function escHtml(str) {
  return (str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// Boot
checkCurrentPage();
