// ToS Guard - Content Script
// Runs on every page, detects ToS content, injects UI

(function () {
  if (window.__tosGuardInitialized) return;
  window.__tosGuardInitialized = true;

  const TOS_SIGNALS = [
    /terms\s+of\s+(service|use)/i,
    /privacy\s+policy/i,
    /user\s+agreement/i,
    /end\s+user\s+licen[sc]e/i,
    /terms\s+and\s+conditions/i,
    /acceptable\s+use\s+policy/i,
    /service\s+agreement/i,
    /legal\s+agreement/i,
  ];

  const URL_SIGNALS = [
    /\/terms/i,
    /\/tos/i,
    /\/privacy/i,
    /\/legal/i,
    /\/eula/i,
    /\/conditions/i,
    /\/agreement/i,
    /\/policy/i,
  ];

  function isTosPage() {
    const url = window.location.href;
    const title = document.title || '';
    const h1Text = Array.from(document.querySelectorAll('h1,h2'))
      .map(el => el.innerText || '')
      .join(' ');

    const urlMatch = URL_SIGNALS.some(r => r.test(url));
    const titleMatch = TOS_SIGNALS.some(r => r.test(title));
    const headingMatch = TOS_SIGNALS.some(r => r.test(h1Text));

    return urlMatch || titleMatch || headingMatch;
  }

  function extractTosText() {
    const selectors = ['main', 'article', '.terms', '.privacy', '.legal', '#content', '.content', 'body'];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el) {
        const text = el.innerText || el.textContent || '';
        if (text.trim().length > 500) {
          return text.trim().slice(0, 12000);
        }
      }
    }
    return (document.body.innerText || '').slice(0, 12000);
  }

  function injectBanner() {
    if (document.getElementById('tos-guard-banner')) return;

    const banner = document.createElement('div');
    banner.id = 'tos-guard-banner';
    banner.innerHTML = `
      <div id="tg-inner">
        <div id="tg-left">
          <span id="tg-icon">🛡️</span>
          <div>
            <div id="tg-title">ToS Guard detected a Terms of Service</div>
            <div id="tg-sub">Click to scan for red flags</div>
          </div>
        </div>
        <div id="tg-actions">
          <button id="tg-scan-btn">Scan Now</button>
          <button id="tg-dismiss-btn">✕</button>
        </div>
      </div>
    `;

    const style = document.createElement('style');
    style.textContent = `
      #tos-guard-banner {
        position: fixed;
        bottom: 24px;
        right: 24px;
        z-index: 2147483647;
        width: 340px;
        background: #0f0f0f;
        border: 1px solid #2a2a2a;
        border-radius: 14px;
        box-shadow: 0 8px 32px rgba(0,0,0,0.4);
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        animation: tg-slide-in 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
        overflow: hidden;
      }
      @keyframes tg-slide-in {
        from { transform: translateY(20px); opacity: 0; }
        to { transform: translateY(0); opacity: 1; }
      }
      #tg-inner {
        padding: 14px 16px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
      }
      #tg-left {
        display: flex;
        align-items: center;
        gap: 10px;
        flex: 1;
        min-width: 0;
      }
      #tg-icon { font-size: 22px; flex-shrink: 0; }
      #tg-title {
        font-size: 13px;
        font-weight: 600;
        color: #fff;
        line-height: 1.3;
      }
      #tg-sub {
        font-size: 11px;
        color: #888;
        margin-top: 2px;
      }
      #tg-actions {
        display: flex;
        align-items: center;
        gap: 8px;
        flex-shrink: 0;
      }
      #tg-scan-btn {
        background: #4f8ef7;
        color: #fff;
        border: none;
        border-radius: 8px;
        padding: 7px 14px;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        transition: background 0.15s;
        white-space: nowrap;
      }
      #tg-scan-btn:hover { background: #3a7aed; }
      #tg-dismiss-btn {
        background: transparent;
        color: #555;
        border: none;
        font-size: 16px;
        cursor: pointer;
        padding: 4px;
        line-height: 1;
        transition: color 0.15s;
      }
      #tg-dismiss-btn:hover { color: #aaa; }
    `;

    document.head.appendChild(style);
    document.body.appendChild(banner);

    document.getElementById('tg-dismiss-btn').addEventListener('click', () => {
      banner.style.animation = 'none';
      banner.style.opacity = '0';
      banner.style.transform = 'translateY(10px)';
      banner.style.transition = 'all 0.2s';
      setTimeout(() => banner.remove(), 200);
    });

    document.getElementById('tg-scan-btn').addEventListener('click', () => {
      const tosText = extractTosText();
      chrome.runtime.sendMessage({
        type: 'SCAN_TOS',
        text: tosText,
        url: window.location.href,
        title: document.title
      });
      banner.remove();
    });
  }

  // Listen for messages from popup or background
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'CHECK_PAGE') {
      sendResponse({ isTos: isTosPage() });
    }
    if (msg.type === 'GET_TOS_TEXT') {
      sendResponse({ text: extractTosText(), title: document.title, url: window.location.href });
    }
    if (msg.type === 'SHOW_BANNER') {
      injectBanner();
    }
    return true;
  });

  // Auto-detect on load
  if (isTosPage()) {
    setTimeout(injectBanner, 800);
    chrome.runtime.sendMessage({ type: 'TOS_DETECTED', url: window.location.href });
  }
})();
