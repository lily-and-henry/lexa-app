// ToS Guard - Background Service Worker
// API calls proxied through your Vercel server — no user key needed

// ---------------------------------------------------------------
// IMPORTANT: After deploying to Vercel, replace this URL with
// your actual deployment URL, e.g.:
// const PROXY_URL = 'https://tos-guard-server.vercel.app/api/analyze';
// ---------------------------------------------------------------
const PROXY_URL = 'https://YOUR-VERCEL-APP.vercel.app/api/analyze';

const RED_FLAG_PATTERNS = [
  { pattern: /sell.*personal.*data|share.*third.?part/i, label: "May sell or share your personal data" },
  { pattern: /arbitration|waive.*right.*sue|class.*action/i, label: "Mandatory arbitration / waives right to sue" },
  { pattern: /terminate.*account.*any.*reason|suspend.*without.*notice/i, label: "Can terminate your account without reason or notice" },
  { pattern: /modify.*terms.*without.*notice|change.*anytime/i, label: "Terms can change without notifying you" },
  { pattern: /own.*content|license.*perpetual.*irrevocable/i, label: "They claim broad rights over your content" },
  { pattern: /track.*location|precise.*location/i, label: "Tracks your precise location" },
  { pattern: /share.*government|law.*enforcement.*request/i, label: "Shares data with government / law enforcement" },
  { pattern: /facial.*recogni|biometric/i, label: "Collects biometric or facial recognition data" },
];

async function analyzeTos(text) {
  // Quick local pre-scan
  const localFlags = RED_FLAG_PATTERNS
    .filter(({ pattern }) => pattern.test(text))
    .map(({ label }) => label);

  try {
    const response = await fetch(PROXY_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text })
    });

    if (!response.ok) {
      const err = await response.json();
      throw new Error(err.error || `Server error ${response.status}`);
    }

    const data = await response.json();
    if (!data.success) throw new Error(data.error || 'Analysis failed');

    // Merge local flags in case AI missed any
    const allFlags = [...new Set([...data.result.redFlags, ...localFlags])];
    data.result.redFlags = allFlags.slice(0, 8);

    return { success: true, result: data.result };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

// Listen for messages
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'TOS_DETECTED') {
    if (sender.tab?.id) {
      chrome.action.setBadgeText({ text: '!', tabId: sender.tab.id });
      chrome.action.setBadgeBackgroundColor({ color: '#f59e0b', tabId: sender.tab.id });
    }
  }

  if (msg.type === 'SCAN_TOS') {
    const { text, url, title } = msg;
    const tabId = sender.tab?.id;
    chrome.storage.local.set({
      pendingScan: { text, url, title, tabId, timestamp: Date.now() },
      scanStatus: 'pending'
    });
    if (tabId) {
      chrome.action.setBadgeText({ text: '…', tabId });
      chrome.action.setBadgeBackgroundColor({ color: '#4f8ef7', tabId });
    }
    sendResponse({ queued: true });
    return true;
  }

  if (msg.type === 'RUN_ANALYSIS') {
    const { text } = msg;
    analyzeTos(text).then(result => {
      chrome.storage.local.set({ lastResult: result, scanStatus: 'done' });
      sendResponse(result);
    });
    return true;
  }

  if (msg.type === 'CLEAR_BADGE') {
    if (msg.tabId) chrome.action.setBadgeText({ text: '', tabId: msg.tabId });
  }

  return true;
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === 'loading') {
    chrome.action.setBadgeText({ text: '', tabId });
  }
});
